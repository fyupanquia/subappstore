<?php 

$reponse[]=array("status"=>0,"status2"=>1);

echo json_encode($reponse) ;
echo "<br/><br/><br/>";

$reponse = array(
    "status" => 1,
    "status2" => 2,
);


echo json_encode($reponse) ;

 ?>