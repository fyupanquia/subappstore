<link id="bs-css" href="css/bootstrap-cerulean.min.css" rel="stylesheet">
<link href="css/charisma-app.css" rel="stylesheet">
    <link href='css/bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='css/bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <!-- jQuery -->
    <script src="js/bower_components/jquery/jquery.min.js"></script>