
 <script src="js/segundero.js"></script>