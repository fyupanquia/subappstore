<link rel="shortcut icon" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="lib/bootstrap3/dist/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="font-awesome-4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/theme.css">
<link rel="stylesheet" type="text/css" href="css/form-edit-product-estyle.css">