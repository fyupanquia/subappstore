<link rel="stylesheet" type="text/css" href="../../lib/jquery-tabs/jquery-ui.css">
<script src="../../lib/jquery-tabs/jquery-ui.js"></script>