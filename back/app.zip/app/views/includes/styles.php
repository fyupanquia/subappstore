<link rel="icon" href="imagenes/favicon.ico">
<link href="iconos/font-awesome-4.3.0/css/font-awesome.css" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link href="estilos/css/bootstrap.min.css" rel="stylesheet">