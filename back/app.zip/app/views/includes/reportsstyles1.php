<script src="js/bower_components/flot/jquery.flot.js"></script>
                                                <script src="js/bower_components/flot/jquery.flot.pie.js"></script>
                                                <script src="js/bower_components/flot/jquery.flot.stack.js"></script>
                                                
                                                <!-- chart libraries end -->
                                                <script src="js/init-chart.js"></script>