//////////MOBILE REDIRECT ///////2013-03-17///////

<!--
if (screen.width <= 855) {
document.location = "http://m.dell.com/mt/www.alienware.com/";
}
//-->
