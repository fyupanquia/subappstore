<?php
define("DB_HOST", "localhost");
define("DB_USER", "u359017581_admin");
define("DB_PASSWORD", "_administrador_");
define("DB_DATABASE", "u359017581_sasp");
?>